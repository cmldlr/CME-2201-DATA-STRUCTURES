import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
public class Graph {
	private HashMap<String, Vertex> vertices;
	private HashMap<String, Edge> edges;

	public Graph() {
		this.vertices = new HashMap<>();
		this.edges = new HashMap<>();
	}
	public void addEdge(String source, String destination, int weight) {

		if (edges.get(source + "-" + destination) == null && edges.get(destination + "-" + source) == null) {
			Vertex source_v, destination_v;

			if (vertices.get(source) == null) {
				source_v = new Vertex(source);
				vertices.put(source, source_v);
			} else
				source_v = vertices.get(source);

			if (vertices.get(destination) == null) {
				destination_v = new Vertex(destination);
				vertices.put(destination, destination_v);
			} else
				destination_v = vertices.get(destination);

			Edge edge = new Edge(source_v, destination_v, weight);
			/*source_v.addEdge(edge);
			destination_v.addEdge(edge);*/
			source_v.addNeighbors(destination_v);
			destination_v.addNeighbors(source_v);
			edges.put(source + "-" + destination, edge);
		} 
		else {
			System.out.println("This edge has already added!");
		}
	}
	public Iterable<Vertex> vertices() {
		return vertices.values();
	}

	public Iterable<Edge> edges() {
		return edges.values();
	}

	public int size() {
		return vertices.size();
	}
	public int edgesSize() {
		return edges.size();
	}
	private void resetVertices() {
		for(Vertex vertex:vertices.values()) {
			vertex.unvisit();
			vertex.setCost(0);
			vertex.setPreviousVertex(null);
		}	
	}
	private int findSP(Vertex originVertex,Vertex endVertex,StackInterface<Vertex>path) {
		resetVertices();
		QueueInterface<Vertex> vertexQueue=new LinkedQueue<>();
		originVertex.setVisited(true);
		boolean done=false;
		vertexQueue.enqueue(originVertex);
	 	while(!done && !vertexQueue.isEmpty()) {
			Vertex frontVertex = vertexQueue.dequeue();						
			Iterator<Vertex> neighbors = frontVertex.getNeighbors().iterator();
			while(!done && neighbors.hasNext()) {
				Vertex nextNeighbor=neighbors.next();
				if (!nextNeighbor.isVisited())
				{
					nextNeighbor.setVisited(true);
					nextNeighbor.setCost(1 + frontVertex.getCost());
					nextNeighbor.setPreviousVertex(frontVertex);
					vertexQueue.enqueue(nextNeighbor);
				} 
				if (nextNeighbor.equals(endVertex)) {
					done = true;
				}
					
			}												
		}
		int pathLength=endVertex.getCost();
		path.push(endVertex);
		Vertex vertex=endVertex;
		while (vertex.hasPreviousVertex())
		{ 
			vertex = vertex.getPreviousVertex();
			path.push(vertex);
		}
		return pathLength;
		
	}
    public void BetweennessAndCloseness() {
    	Vertex highestVertexforB=new Vertex();
    	Vertex highestVertexforC=new Vertex();
    	 for (Vertex originVertex:vertices.values()) {
    		originVertex.setFound_sp(true);
    		int countOfpathLength=0;
    		 for(Vertex endVertex:vertices.values()) {
    			StackInterface<Vertex> path=new LinkedStack<>(); 
    			if(!originVertex.equals(endVertex)) {
    				int pathLength=findSP(originVertex, endVertex, path);
    				countOfpathLength=countOfpathLength+pathLength;
    				if(!endVertex.isFound_sp()) {
    					if(pathLength>0) {
        					calculateBetweenness(path);
        				}
    				}
    			}
    		}
    		calculateCloseness(originVertex,countOfpathLength);
    		
    		if(highestVertexforB.getBetweenness()<originVertex.getBetweenness()) {
				highestVertexforB=originVertex;
			}
			if(highestVertexforC.getCloseness()<originVertex.getCloseness() &&originVertex.getCloseness()<1.0) {
				highestVertexforC=originVertex;
			}
			
			
    	}
    	
    	printResult(highestVertexforB,highestVertexforC);
	} 
    private void printResult(Vertex highestVertexforB,Vertex highestVertexforC) {
    	System.out.println("-->The Highest Vertex for Betweennes and the value ");
    	System.out.println("--->Vertex's name:"+highestVertexforB.getName() +"\n--->Vertex's value:"+highestVertexforB.getBetweenness());
    	System.out.println("-->The Highest Vertex for Closeness and the value ");
    	System.out.println("--->Vertex's name:"+highestVertexforC.getName() +"\n--->Vertex's value:"+highestVertexforC.getCloseness());
    }
    private void calculateBetweenness(StackInterface<Vertex> path) {
    	while(!path.isEmpty()) {
    		Vertex vertex=path.pop();
    		vertex.setBetweenness(vertex.getBetweenness()+1);
    	}	
    }
    private void calculateCloseness(Vertex originVertex,int countOfpathLength) {
    	//closeness=n-1/countofpathLength
		double closeness=(double)(size()-1)/countOfpathLength;
		originVertex.setCloseness(closeness);		
    }
    

	

}
