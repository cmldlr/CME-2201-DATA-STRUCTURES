import java.util.ArrayList;
import java.util.Iterator;

public class Vertex {
	private String name;
	private ArrayList<Edge> edges;
	private ArrayList<Vertex> neighbors;
	private Vertex previousVertex;
	private int betweenness;
	private double closeness;
    private boolean visited;
    private boolean found_sp;//found all  shorts parts
    private int cost;
	public Vertex(String name) {
		this.name = name;
		edges = new ArrayList<Edge>();
		neighbors=new ArrayList<Vertex>();
		previousVertex = null;
		betweenness=0;
		closeness=0.0;
		visited=false;
		found_sp=false;
		cost=0;
		
		
	}
    public Vertex() {
    	betweenness=0;
		closeness=0.0;
    }
	public void addEdge(Edge e) {
		edges.add(e);
	}
    public void addNeighbors(Vertex neighorsVertex) {
    	neighbors.add(neighorsVertex);
    }
	public ArrayList<Edge> getEdges() {
		return this.edges;
	}

	public ArrayList<Vertex> getNeighbors() {
		return neighbors;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public Vertex getPreviousVertex() {
		return previousVertex;
	}
	public void setPreviousVertex(Vertex previousVertex) {
		this.previousVertex = previousVertex;
	}
	public boolean hasPreviousVertex() {
		boolean hasPreviousVertex=false;
		if(getPreviousVertex()!=null) {
			hasPreviousVertex=true;
		}
		return  hasPreviousVertex;
	}
	public boolean isVisited() {
		return visited;
	}
	public void unvisit() {
		this.visited=false;
	}
	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	public boolean isFound_sp() {
		return found_sp;
	}
	public void setFound_sp(boolean found_sp) {
		this.found_sp = found_sp;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getBetweenness() {
		return betweenness;
	}
	public void setBetweenness(int betweenness) {
		this.betweenness = betweenness;
	}
	public double getCloseness() {
		return closeness;
	}
	public void setCloseness(double closeness) {
		this.closeness = closeness;
	}
	
	
	
	

}
