import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException {
		System.out.println("2019510025_Cemil_DALAR");
		System.out.println("");
		FileReader fr=new FileReader("karate_club_network.txt");
		BufferedReader br=new BufferedReader(fr);
		String readBuffer=" ";
		Graph karate_club_network=new Graph();
		while((readBuffer=br.readLine())!=null) {
			String words[]=readBuffer.split(" ");
			karate_club_network.addEdge(words[0], words[1], 1);
		}
		System.out.println("->Zachary Karate Club Network  ");
		karate_club_network.BetweennessAndCloseness();
		System.out.println("");
		System.out.println("It will take a little time to load facebook's network data. PLEASE WAIT..");
		System.out.println("");
		FileReader fr2=new FileReader("facebook_social_network.txt");
		BufferedReader br2=new BufferedReader(fr2);
		String readBuffer2=" ";
		Graph facebook_social_network=new Graph();
		while((readBuffer2=br2.readLine())!=null) {
			String words[]=readBuffer2.split(" ");
			facebook_social_network.addEdge(words[0], words[1], 1);
		}
		System.out.println("->Facebook Social Network");
		facebook_social_network.BetweennessAndCloseness();
       
        		
	}

}
