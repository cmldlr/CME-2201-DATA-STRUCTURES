import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) throws IOException {
		Scanner scn=new Scanner(System.in);
		boolean flag1 = true;
        boolean flag2 = true;
        boolean flag3=true;
        //Taking an input for load factor
        System.out.println("Please select a load factor! \n1--> 50% Load Factor" + "\n2--> 80% Load Factor");
        double load_factor =0.5;
        int selectionForLoadFactor = scn.nextInt();
        while(flag1){
            switch (selectionForLoadFactor){
                case 1:
                	load_factor =0.50; //50%
                    flag1 = false;
                    break;
                case 2:
                	load_factor =0.80; //80%
                    flag1 = false;
                    break;
                default:
                    System.out.print("Wrong character! Please press 1 or 2 !");
                    System.out.println("\n1--> 50% Load Factor" + "\n2--> 80% Load Factor");
                    selectionForLoadFactor = scn.nextInt();
            }
        }
      //Taking input for hash function
        System.out.println("Please select the which hash code function you will use!" +
                "\n1--> Simple Summation Function (SSF)" + "\n2--> Polynomial Accumulation Function (PAF)");
        int hash_function=1;
        int selectionForHashCodeFunction = scn.nextInt();
        while(flag2){
            switch (selectionForHashCodeFunction){
                case 1:
                	hash_function = 1; // SSF
                    flag2 = false;
                    break;
                case 2:
                	hash_function = 2; // PAF
                    flag2 = false;
                    break;
                default:
                    System.out.println("Wrong character! Please press 1 or 2 !");
                    System.out.print("1--> Simple Summation Function (SSF)" + "\n2--> Polynomial Accumulation Function (PAF)");
                    selectionForHashCodeFunction = scn.nextInt();
            }
        }
        System.out.println("Please select the which collison handling you will use!" +
                "\n1--> Linear Probing (LP)" + "\n2--> Double Hashing (DH)");
        int collison_handling=1;
        int selectionForCollisonHandling = scn.nextInt();
        while(flag3){
            switch (selectionForCollisonHandling){
                case 1:
                	collison_handling = 1; // SSF
                    flag3 = false;
                    break;
                case 2:
                	collison_handling = 2; // PAF
                    flag3 = false;
                    break;
                default:
                    System.out.println("Wrong character! Please press 1 or 2 !");
                    System.out.print("1--> Linear Probing (LP)" + "\n2--> Double Hashing (DH)");
                    selectionForHashCodeFunction = scn.nextInt();
            }
        }
        System.out.println(" ");
        HashedDictionary hashdictionary=new HashedDictionary<>(hash_function, collison_handling, load_factor);
		FileReader fr=new FileReader("stop_words_en.txt");
		BufferedReader br=new BufferedReader(fr);
		String read_stopwords="";
		String stopwords[]=new String[575];
	    int index=0;
	    int count=0;
		while((read_stopwords=br.readLine())!=null){
			if(count%2==0) {
				stopwords[index]=read_stopwords;
				index++;
			}
			count++;
		}
		String DELIMITERS = "[-+=" +

		        " " +        //space

		        "\r\n " +    //carriage return line fit

				"1234567890" + //numbers
				

				"’'\"" +       // apostrophe

				"(){}<>\\[\\]" + // brackets

				":" +        // colon

				"," +        // comma

				"‒–—―" +     // dashes

				"…" +        // ellipsis

				"!" +        // exclamation mark

				"." +        // full stop/period

				"«»" +       // guillemets

				"-‐" +       // hyphen

				"?" +        // question mark

				"‘’“”" +     // quotation marks

				";" +        // semicolon

				"/" +        // slash/stroke

				"⁄" +        // solidus

				"␠" +        // space?   

				"·" +        // interpunct

				"&" +        // ampersand

				"@" +        // at sign

				"*" +        // asterisk

				"\\" +       // backslash

				"•" +        // bullet

				"^" +        // caret

				"¤¢$€£¥₩₪" + // currency

				"†‡" +       // dagger

				"°" +        // degree

				"¡" +        // inverted exclamation point

				"¿" +        // inverted question mark

				"¬" +        // negation

				"#" +        // number sign (hashtag)

				"№" +        // numero sign ()

				"%‰‱" +      // percent and related signs

				"¶" +        // pilcrow

				"′" +        // prime

				"§" +        // section sign

				"~" +        // tilde/swung dash

				"¨" +        // umlaut/diaeresis

				"_" +        // underscore/understrike

				"|¦" +       // vertical/pipe/broken bar

				"⁂" +        // asterism

				"☞" +        // index/fist

				"∴" +        // therefore sign

				"‽" +        // interrobang

				"※" +          // reference mark

		        "]";
        String inpath="bbc";
        File Folder=new File(inpath);
        File Folders[]=Folder.listFiles();//business entertainment politics sport tech
        long startTime = System.nanoTime();
        for(int i=0;i<Folders.length;i++){//business entertainment politics sport tech
        	File Files[]=Folders[i].listFiles();//txt files        	
        	for (int j = 0; j <Files.length; j++) {
        		 String FileName=Files[j].getName();
               if(FileName.endsWith("txt")){                   
                     BufferedReader streamIn = new BufferedReader(new FileReader(Files[j].toString()));
                     String readLine;
                     while ((readLine = streamIn.readLine()) != null) {
                    	 String words[]=readLine.split(" ");
                    	 
                     	for (int k = 0; k < words.length; k++) {
 							for (int l = 0; l < stopwords.length; l++) {
 								if(words[k].equals(stopwords[l])){
 									words[k]=" ";
 								}
 							}
 						}
                     	String readLine1="";
                     	for (int k = 0; k < words.length; k++) {
 							readLine1=readLine1+words[k]+" ";
 						}
                     	String addToHash[]=readLine1.split(DELIMITERS);
                     	for (int k = 0; k < addToHash.length; k++) {
                     		
                     		if(addToHash[k].length()>1 ) {
                     		   addToHash[k]=addToHash[k].toLowerCase(Locale.ENGLISH);
                     		   String value=Folders[i].getName()+"_"+Files[j].getName();
                     		   
                     		   hashdictionary.add(addToHash[k], value);
                     		}
							
						}
                     	
                     }
                    
               }
			}
        }
        long finishTime = System.nanoTime();
        long indexingTime = (finishTime - startTime) / 1000000;
        
        FileReader search=new FileReader("search.txt");
        BufferedReader br2=new BufferedReader(search);
        String search_key="";
        long beginningTime = 0;
        long finishingTime = 0;
        long time = 0;
        long minSearchTime = 0;
        long maxSearchTime = 0;
        long averageSearchTime = 0;
        int  number_of_searched_words=0;
        while((search_key=br2.readLine())!=null) {
        	beginningTime = System.nanoTime();//starting time
        	hashdictionary.search(search_key);
        	finishingTime = System.nanoTime();//finishing time
        	time = finishingTime - beginningTime;//searching time for each word
        	averageSearchTime = averageSearchTime + time;//total searching time
             //determining max and min searching times
             if(number_of_searched_words == 0){
                 minSearchTime = time;
                 maxSearchTime = time;
             }
             else if(time < minSearchTime){
                 minSearchTime = time;
             }
             else if(time > maxSearchTime){
                 maxSearchTime = time;
             }
             number_of_searched_words++;
        }
        averageSearchTime = averageSearchTime /number_of_searched_words;

        //outputs
        System.out.println("-->The number of the collision: " + hashdictionary.getCollisionCounter());
        System.out.println("-->Indexing time: " + indexingTime + " milliseconds according to the Load Factor,the Collison Handling \nand the Hash Code Function you have selected.");
        System.out.println("-->The Average Search Time for the words in search.txt " + averageSearchTime + " nanoseconds");
        System.out.println("-->The Minimum Search time for the words in search.txt " + minSearchTime + " nanoseconds");
        System.out.println("-->The Maximum Search Time for the words in search.txt " + maxSearchTime + " nanoseconds");
        System.out.println("-->The current capacity of the Hash Table is: " + hashdictionary.getNumberOfElements());
        hashdictionary.search_summary();
        boolean menu=true;
        System.out.println(" ");
        System.out.println("What do you want to do?");
        System.out.println("0-exit()"+"\n1-add()"+"\n2-getValue()"+"\n3-remove()");
        int choose=scn.nextInt();
        while(menu) {
        	 if(choose==1){
        		 System.out.println("Please enter the key.");
             	 String key=scn.next();
             	 System.out.println("Please enter the key's location(foldersname_txtname).");
             	 String value=scn.next();
             	 hashdictionary.add(key, value);
             	 System.out.println(" ");
                 
        	 }
        	 else if(choose==2) {
        		 System.out.println("Which value do you want to get? Please enter the key");
             	 String key1=scn.next();
             	 hashdictionary.getValue(key1);
             	 System.out.println(" ");
                
        	 }
        	 else if(choose==3) {
        		 System.out.println("Which value do you want to remove?");
             	 System.out.println("Please enter the key.");
             	 String key2=scn.next();
             	 hashdictionary.remove(key2);
             	 System.out.println(" ");
             	
        	 }
        	 else if(choose==0) {
        		 System.out.println("logged out");
                 menu=false;
                 break;
        	 }
        	 else {
        		 System.out.println("Wrong character! Please press 1 or 2 !");
        		 System.out.println("0-exit()"+"\n1-add()"+"\n2-getValue()"+"\n3-remove()");
                 choose = scn.nextInt();
        	 }
        	 System.out.println("0-exit()"+"\n1-add()"+"\n2-getValue()"+"\n3-remove()");
        	 choose=scn.nextInt();
            
        }
		
	}

}
