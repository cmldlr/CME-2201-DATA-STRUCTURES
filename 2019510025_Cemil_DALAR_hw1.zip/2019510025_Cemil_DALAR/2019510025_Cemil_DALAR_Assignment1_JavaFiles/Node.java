public class Node {
    private Object data;
    private int frequency;
    private Node link;


    public Node(Object dataToAdd){
        data=dataToAdd;
        link=null;
    }
    public Node(Object dataToAdd,int frequency){
    	this.frequency=frequency;
		this.data=dataToAdd;
        link=null;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Node getLink() {
        return link;
    }

    public void setLink(Node link) {
        this.link = link;
    }


	public int getFrequency() {
		return frequency;
	}


	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
}    
