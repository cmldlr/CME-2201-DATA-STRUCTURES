
public class LinkedList {
    private Node head;
    public void add(Object dataToAdd){
        if(head==null){
            Node newNode= new Node(dataToAdd);
            head=newNode;

        }
        else if((Integer)dataToAdd<(Integer)head.getData()){
            Node newNode= new Node(dataToAdd);
            newNode.setLink(head);
            head=newNode;
        }
        else {
            Node temp=head;
            Node previous=null;
            while (temp!=null &&(Integer)dataToAdd>(Integer)temp.getData()){
                previous=temp;
                temp=temp.getLink();
            }
            if(temp==null){
                Node newNode=new Node(dataToAdd);
                previous.setLink(newNode);
            }
            else{
                Node newNode=new Node(dataToAdd);
                newNode.setLink(previous.getLink());
                previous.setLink(newNode);
            }
        }
    }
   

	public void unordered_addition(Object dataToAdd){
		int frequency=1;
        if(head==null){
            Node newNode= new Node(dataToAdd,frequency);
            head=newNode;

        }
        else {
            Node temp=head;
            Node previous=null;
            while (temp!=null){
                previous=temp;
                temp=temp.getLink();
            }
            if(temp==null){
            	 Node newNode= new Node(dataToAdd,frequency);
                previous.setLink(newNode);
            }
        }
    }

    public void addString(Object dataToAdd){
        if(head==null){
            Node newNode= new Node(dataToAdd);
            head=newNode;

        }
        else if(String.valueOf(dataToAdd).compareTo(String.valueOf(head.getData()))<0){
            Node newNode= new Node(dataToAdd);
            newNode.setLink(head);
            head=newNode;

        }
        else {
            Node temp=head;
            Node previous=null;
            while (temp!=null &&String.valueOf(dataToAdd).compareTo(String.valueOf(temp.getData()))>0){
                previous=temp;
                temp=temp.getLink();
            }
            if(temp==null){
                Node newNode=new Node(dataToAdd);
                previous.setLink(newNode);
            }
            else{
                Node newNode=new Node(dataToAdd);
                newNode.setLink(previous.getLink());
                previous.setLink(newNode);
            }
        }



    }



    public void delete(Object data){
        boolean flag=true;
        if(head==null){
            System.out.println("Linked list is empty");
        }
        else {
            if(String.valueOf(head.getData()).equalsIgnoreCase(String.valueOf(data))){
                head=head.getLink();
                flag=false;

                if(head!=null && String.valueOf(head.getData()).equalsIgnoreCase(String.valueOf(data)) ){
                    head=head.getLink();
                    flag=false;

                }

            }
            Node temp=head;
            Node previous=null;
            while(temp!=null){
                if(String.valueOf(temp.getData()).equalsIgnoreCase(String.valueOf(data))){
                    previous.setLink(temp.getLink());
                    temp=previous;

                    flag=false;
                }
                previous=temp;
                temp=temp.getLink();
            }
            if (flag){
                System.out.println("no found");
            }
        }
    }
    public void print(){
        if(head!=null){
            Node temp = head;
            while (temp != null) {
            	System.out.println(temp.getData()+" "+temp.getFrequency());
                temp = temp.getLink();
            }
        }
    }
    public Node search(int rndnumber){
        String str=" ";
        int count=0;
        Node temp = head;
        if(rndnumber==0){
            return head;
        }
        else{
            while (temp != null) {
                temp = temp.getLink();
                count++;
                if(count==rndnumber){
                    return temp;
                }

            }
        }
        return null;
    }
    public  boolean search(Object item){
        boolean flag = false;
        if (head == null)
            System.out.println("linked list is empty");
        else {
            Node temp = head;
            while (temp != null) {
                if (String.valueOf(item).equalsIgnoreCase(String.valueOf(temp.getData()))){
                    flag = true;
                }
                temp = temp.getLink();
            }
        }
        return flag;
    }
    public int size(){
        int count=0;
        Node temp=head;
        while (temp!=null){
            count++;
            temp=temp.getLink();
        }
        return count;
    }

    public Node getHead() {
        return head;
    }

    public void setHead(Node head) {
        this.head = head;
    }
}
