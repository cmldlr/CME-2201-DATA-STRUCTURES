import java.util.Iterator;
import java.util.NoSuchElementException;
import java.math.*;

public class HashedDictionary<K, V> implements DictionaryInterface<K, V> 
{
   
	private static class TableEntry<S, T>
	{
		private S key;
		private T value;
		private LinkedList values=new LinkedList();
		private States state; // Flags whether this entry is in the hash table
		private enum States {CURRENT, REMOVED} // Possible values of state
		/*private TableEntry(S searchKey, T dataValue)
		{
			key = searchKey;
			value = dataValue;
			state = States.CURRENT;
		} // end constructor*/
		private TableEntry(S searchKey, T dataValue)
		{
			key = searchKey;
			values.unordered_addition(dataValue);
			value = dataValue;
			state = States.CURRENT;
		} // end constructor
		private void add(T value) {
			values.unordered_addition(value);
		}
		public LinkedList getValues() {
			return values;
		}

		public void setValues(LinkedList values) {
			this.values = values;
		}

		public S getKey() {
			// TODO Auto-generated method stub
			return this.key;
		}
		
		private T getValue()
		{
			return value;
		} // end getValue
		private void setValue(T newValue)
		{
		    value = newValue;
		} // end setValue
		public boolean isIn() {
			boolean isIn=false;
			if (state==state.CURRENT) {
				isIn=true;
			}
			return isIn;
		}
		public boolean isRemoved() {
			// TODO Auto-generated method stub
			return false;
		}
		public void setToRemoved() {
			state = States.REMOVED;
			
		}
		
	}
	private int numberOfEntries;
	private static final int DEFAULT_CAPACITY =5; // Must be prime	
	private TableEntry<K, V>[] hashTable;
	private int tableSize; // Must be prime
	private boolean initialized = false;
	private int hash_function;
	private int collison_handling;
	private double load_factor;
	private int succesful_search=0;
	private int unseccesful_search=0;
	private long collision_counter=0;
	private boolean count_collison=true;
	
	public HashedDictionary(int hash_function,int collison_handling,double load_factor)
	{
		this.hash_function=hash_function;
		this.collison_handling=collison_handling;
		this.load_factor=load_factor;
		numberOfEntries = 0; 
		int tableSize = (int)nextPrime(DEFAULT_CAPACITY);
		TableEntry<K, V>[] temp = (TableEntry<K, V>[])new TableEntry[tableSize];
		hashTable = temp;
		initialized = true;
	} 
	static long nextPrime(long n)
    {
        BigInteger b = new BigInteger(String.valueOf(n));
        return Long.parseLong(b.nextProbablePrime().toString());
    }
	
	private int locate(int index, K key)
	{
		int q=7;
		int k=index;
		int h=k%hashTable.length;
		int h1=index%hashTable.length;
		int d=q-k%q;
		int count=1;
		int a=index%hashTable.length;
		
		int L_index;
		boolean found = false;
		if(collison_handling==1) {//linear probing
			while ( !found && (hashTable[a] != null) )
			{
				if ( hashTable[a].isIn() && key.equals(hashTable[a].getKey()) )
						found = true; // Key found
				else{
					a = (a + 1) % hashTable.length; // Linear probing					
				}
					
			} 
		}
		else {//double hashing
			while ( !found && (hashTable[h] != null) )
			{
				
				if (hashTable[h].isIn())
				{
					if (key.equals(hashTable[h].getKey()))
						found = true; // Key found
					else {// Follow probe sequence	///double hashing
						h=(h1+(count*d))%hashTable.length;
						count++;
						
					}
						
				}
			}	
		}
		
		// Assertion: Either key or null is found at hashTable[index]
		int result = -1;
		if (found) {
			if(collison_handling==1) {
				result=a;
			}
			else {
				result=h;
			}
		}
			
		return result;
	} // end locate
	
	private int probe(int index, K key)//linear probing
	{
		boolean found = false;
		int removedStateIndex = -1; // Index of first location in removed state
		while ( !found && hashTable[index] != null )
		{
			if (hashTable[index].isIn())
			{
				if (key.equals(hashTable[index].getKey()))
					found = true; // Key found
				else {// Follow probe sequence				
					index = (index + 1) % hashTable.length; // Linear probing
					if(count_collison) {
						collision_counter++;
					}
					
				}
					
			}
			else // Skip entries that were removed
			{
				// Save index of first location in removed state
				if (removedStateIndex == -1)
				     removedStateIndex = index;
				index = (index + 1) % hashTable.length; // Linear probing
				if(count_collison) {
					collision_counter++;
				}
			} // end if
		} // end while
		// Assertion: Either key or null is found at hashTable[index]
		if (found || (removedStateIndex == -1) ) {
			   return index; // Index of either key or null
		}			
		else
		   return removedStateIndex; // Index of an available location
	}
	private void enlargeHashTable()
	{
		TableEntry<K, V>[] oldTable = hashTable;
		int oldSize = hashTable.length;
		int newSize =(int)nextPrime(oldSize + oldSize);
		TableEntry<K, V>[] temp = (TableEntry<K, V>[])new TableEntry[newSize];
		hashTable = temp;
		numberOfEntries = 0;
		count_collison=false;
		for (int index = 0; index < oldSize; index++)
		{
			if ( (oldTable[index] != null) && oldTable[index].isIn() )
				add(oldTable[index].getKey(), oldTable[index].getValues());
		}
		count_collison=true;
	}

	private LinkedList add(K key,LinkedList values) {
		int index = getHashIndex(key);
		if(collison_handling==1) {//linear probing	
			//System.out.println(hashTable.length);
			index = probe(index%hashTable.length, key);
			
		}
		else {//double hashing
			index=dh(index,key);
		}
		assert (index >= 0) && (index < hashTable.length);
		
		Node temp=values.getHead();
        while (temp!=null ){
        	
        	if(hashTable[index]==null) {
        		String data=(String) temp.getData();
        		V value=(V) data;
        		hashTable[index] = new TableEntry<>(key,value );
                hashTable[index].getValues().getHead().setFrequency(temp.getFrequency());
        	}
        	else {
        		
                String vle1=(String)temp.getData();
                V value1=(V) vle1;
            	hashTable[index].add(value1);
            	Node temp1=hashTable[index].getValues().getHead();
            	while(temp1!=null) {
            		if(temp.getData()==temp1.getData()) {
            			temp1.setFrequency(temp.getFrequency());
            		}
            		temp1=temp1.getLink();
            	}
            	
        	}            		
        	temp=temp.getLink();
        	
        	
        	
        }
		numberOfEntries++;					
		return values;
		
	}
	public V add(K key, V value)
	{
		if ((key == null) || (value == null))
		      throw new IllegalArgumentException();
		else
		{		
			V oldValue=null;// Value to return
			int index = getHashIndex(key);
			if(collison_handling==1) {//linear probing
				index = probe(index%hashTable.length, key);
			}
			else {//double hashing
				index=dh(index,key);
			}
			assert (index >= 0) && (index < hashTable.length);
			if ( (hashTable[index] == null) || hashTable[index].isRemoved())
			{ // Key not found, so insert new entry
				hashTable[index] = new TableEntry<>(key, value);
				numberOfEntries++;
			}
			else
			{ // Key found; get old value for return and then replace it
				Node temp=hashTable[index].getValues().getHead();
				boolean found=false;
				while(temp!=null) {
					if(temp.getData().equals(value)) {
						temp.setFrequency(temp.getFrequency()+1);
						found=true;
					}
					temp=temp.getLink();
				}
				if(found==false) {
					hashTable[index].add(value);
				}
				
			}
			if(isHashTableTooFull()==true) {
				enlargeHashTable();
				
			}			
			return oldValue;
			
		} 	
	
	}
	private int dh(int index, K key) {
		boolean found = false;
		int removedStateIndex = -1; 
		int q=7;
		int k=index;
		int h=k%hashTable.length;
		int h1=k%hashTable.length;	
		int d=q-(k%q);
		int count=1;
		while ( !found && hashTable[h] != null)
		{
			if (hashTable[h].isIn())
			{
				if (key.equals(hashTable[h].getKey()))
					found = true; // Key found
				else {// Follow probe sequence	///double hashing
					h=(h1+(count*d))%hashTable.length;
					count++;
					if(count_collison) {
						collision_counter++;
					}
					
				}
					
			}
			else 
			{
				if (removedStateIndex == -1) {
					removedStateIndex = h;
				}				     
				h=(h1+(count*d))%hashTable.length;
				count++;
				if(count_collison) {
					collision_counter++;
				}
			}
			if(h<0) {
				h=h+hashTable.length;
				
			}
			
			// end while
		}
		
		if (found || (removedStateIndex == -1) ) {
			return h; // Index of either key or null
		}   
		else {
			 return removedStateIndex;
		}
		}
		  
	private boolean isHashTableTooFull() {
		boolean full=false;
		if((double)numberOfEntries/hashTable.length>load_factor) {
			full=true;
		}
		return full;
	}
   
	public void search(K key) {
		//System.out.println(">Search: "+key);
		//checkInitialization();
		V result = null;
	    int index = getHashIndex(key);
		index = locate(index, key);
		if (index != -1) {
			int a = hashTable[index].getValues().size();
			   //System.out.println(a+" documents found");
			   Node temp=hashTable[index].getValues().getHead();
			   succesful_search++;
			   /*while(temp!=null) {
				   System.out.println(temp.getFrequency()+"-"+temp.getData());
				   temp=temp.getLink();
			   }*/
		}
		else {
			unseccesful_search++;
		}
		
	}
	public void search_summary() {
		System.out.println("-->"+succesful_search+" keys found in search.txt");
		System.out.println("-->"+unseccesful_search+" keys not found in search.txt");
	}
	private int getHashIndex(K key) {//find the hash index for key 
		int index=-1;
		int count=0;
		String str=(String) key;
		if(hash_function==1) {//SSF
			for(int i=0;i<str.length();i++) {
				char ch=str.charAt(i);
				int a=(int) ch-96;
				count=count+a;
			}
		}
		else if(hash_function==2) {//PAF
			int key_length=str.length();
			int z=31;
			for(int i=0;i<str.length();i++) {
				char ch=str.charAt(i);
				int a=(int) ch-96;
				int b=(int) (a* Math.pow(z,key_length-1));
				count=count+b;
				key_length--;
			}
		}
		if(count<0) {
			count=0;
			if(hash_function==2) {
				int key_length=str.length();
				int z=2;
				for(int i=0;i<str.length();i++) {
					char ch=str.charAt(i);
					int a=(int) ch-96;
					int b=(int) (a* Math.pow(z,key_length-1));
					count=count+b;
					key_length--;
				}
			}
		}
		index=count;
		return index;
	}
	@Override
	public V remove(K key)
	{
		//checkInitialization();
		V removedValue = null;
		int index = getHashIndex(key);
		index = locate(index, key);
		if (index != -1)
		{ // Key found; flag entry as removed and return its value
		  removedValue = hashTable[index].getValue();
		  hashTable[index].setToRemoved();
		  hashTable[index]=null;
		  numberOfEntries--;
		} // end if
		// Else key not found; return null*/
		return removedValue;
	} 

	@Override
	public V getValue(K key)
	{
		System.out.println(">Search: "+key);
		//checkInitialization();
		V result = null;
	    int index = getHashIndex(key);
		index = locate(index, key);
		if (index != -1) {
			int a = hashTable[index].getValues().size();
			   System.out.println(a+" documents found");
			   Node temp=hashTable[index].getValues().getHead();
			   int count=1;
			   while(temp!=null) {
				   System.out.println(temp.getFrequency()+"-"+temp.getData());
				   temp=temp.getLink();
			   }
		}
		else {
			System.out.println("not found");
		}
		// Else key not found; return null
		return result;
	} // end getValue
    public long getCollisionCounter() {
    	return collision_counter;
    }
	@Override
	public boolean contains(K key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterator<K> getKeyIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<V> getValueIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getSize() {
		
		return hashTable.length;
	}
    public int getNumberOfElements() {
    	return numberOfEntries;
    }
	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
	

} 